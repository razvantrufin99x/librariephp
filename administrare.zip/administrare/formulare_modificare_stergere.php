	<?php
	include("autorizare.php");
	include("admin_top.php");
	
	//modif domeniu
	if(isset($_POST['modifica_domeniu']))
	{
	$sql = "select nume_domeniu from domenii where id_domeniu='".$_POST['id_domeniu']."'";
	$resursa = mysql_query($sql);
	$nume_domeniu = mysql_result($resursa,0,"nume_domeniu");
	?>
	
	<h1> modifica nume domeniu</h1>
	<form action = "prelucrare_modificare_stergere.php" metho="POST">
	<input type = "text" name="nume_domeniu" value ="<?=$nume_domeniu?>">
	<input type="hidden" name="id_domeniu" value="<?=$_POST['id_domeniu']?>">
	<input type = "submit" name="modifica_domeniu" value="modifica">
	</form>
	<?php
	
	}


//sterge domeniu
	if(isset($_POST['stergere_domeniu']))
	{
	$sql = "select titlu, nume_autor from carti where carti.id_domeniu=domenii.id_domeniu and carti.id_autor=autori.id_autor and domenii.id_domeniu=".$_POST['id_domeniu'];
	
	$resursa = mysql_query($sql);
	$nrCarti = mysql_num_rows($resursa);
	
	if($nrCarti > 0)
	{
	print "<p> sunt $nrCarti carti care apartin acestui domeniu !</p>";
	while($row = mysql_fetch_array($resursa))
	{
	print "<b>".$row['titlu']."</b>de ".$row['nume_autor']."<br>";
	}
	print "<p> nu puteti stere acest domeniu !</p>";
	}
	else
	{
	?>
	<h1> sterge nume domeniu </h1>
	esti sigur ca vrei sa stergi acest domeniu ?
	
	<form action = "prelucrare_modificare_stergere.php" metho="POST">
	<input type = "hidden" name="id_domeniu" value ="<?=$_POST['id_domeniu']?>">
	<input type = "submit" name="sterge_domeniu" value="sterge!">
	</form>
	<?php
	
	}
	}
	
	
	if(isset($_POST['modifica_autor']))
	{
	$sql = "select nume_autor from autori where id_autor='".$_POST['id_autor']."'";
	$resursa = mysql_query($sql);
	$nume_autor = mysql_query($resursa, 0 , "nume_autor");
	//$nume_autor = mysql_query($resursa, "nume_autor");
	?>
	
	<h1> modifica nume autor </h1>
	<form action="prelucrare_modificare_stergere.php" method="POST">
	<input type="text" name="nume_autor" value="<?=$nume_autor?>">
	<input type="hidden" name="id_autor" value="<?=$_POST['id_autor']?>">
	<input type="submit" name="modifica_autor" value= "modifica">
	</form>
	
	<?php
	
	}
	
	if(isset($_POST['sterge_autor']))
	{
	$sql = "select titlu from carti , autori where carti.id_autor=autori.id_autor and carti.id_autor=".$_POST['id_autor'];
	$resursa = mysql_query($sql);
	$nrCarti = mysql_num_rows($resursa);
	if($nrCarti > 0)
	{
	print "<p> sunt $nrCarti carti de acest autor in baza de date !</p>";
	while($row = mysql_fetch_array($resursa))
	{
	print $row['titlu']."<br>";
	}
	print "<p> nu puteti sterge acest autor !</p>";
	}
	else
	{
	?>
	<h1>sterge autor</h1>
	esti sigur ca vrei sa stergi acest autor ?
	<form action = "prelucrare_modificare_stergere.php" method ="POST">
	<input type="hidden" name="id_autor" value="<?=$_POST['id_autor']?>">
	<input type="submit" name="sterge_autor" value="sterge">
	</form>
	
	<?php
	}
	}
	

//modifica cartea
	if(isset($_POST['modifica_carte']))
	{
	print "<h1> modifica carte </h1>";
	$sqlCarte = "select * from carti where titlu='".$_POST['titlu']."' and id_autor=".$_POST['id_autor'];
	$resursaCarte = mysql_query($sqlCarte);
	if(mysql_num_rows($resursaCarte)==0)
	{
	print "aceasta carte nu exista in baza de date";
	}
	else
	{
	$rowCarte = mysql_fetch_array($resursaCarte);
	?>
	
	<form action ="prelucrare_modificare_stergere.php" method="POST">
	<table>
	<tr>
	<td> domeniu: </td>
	<td><select name="id_domeniu">
	<?php
	$sql = "select * from domenii order by nume_domeniu asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
	if($row['id_domeniu'] == $rowCarte['id_domeniu'])
	{
	print '<option selected value="'.$row['id_domeniu'].'">'.$row['nume_domeniu'].'</option>';
	}
	else
	{
	print '<option value="'.$row['id_domeniu'].'">'.$row['nume_domeniu'].'</option>';
	}
	}
	?>
	
	</select>
	</td>
	</tr>
	<tr>
	<td>autor:</td>
	<td>
	<select name="id_autor">
	<?php
	$sql = "select * from autori order by nume_autor asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
	if($row['id_autor']==$rowCarte['id_autor'])
	{
	print '<option selected value="'.$row['id_autor'].'">'.	$row['nume_autor'].'</option>';
	}
	else
	{
	print '<option value="'.$row['id_autor'].'">'.
	$row['nume_autor'].'</option>';
	
	}
	}
	?>
	</select>
	</td>
	</tr>
	<tr>
	<td>titlu</td>
	<td>
	<input type="text" name="titlu"  value="<?=$rowCarte['titlu']?>">
	</td>
	</tr>
	<tr>
	<td valign="top">descriere : </td>
	<td> <textarea name="descriere" rows = "8" ><?=$rowCarte['descriere']?>
	</textarea></td>
	</tr>
	<tr>
	<td> pret:</td>
	<td><input type="text" name="pret" value="<?=$rowCarte['pret']?>">
	</td></tr>
	</table>
	<input type="hidden" name="id_carte" value="<?=$rowCarte['id_carte']?>">
	<input type ="submit" name="modifica_carte" value="modifica">
	</form>
	<?php
	}
	}
 //sterge cartea
 if(isset($_POST['sterge_carte']))
 {
 print "<h1> sterge carte </h1>";
 $sqlCarte = "select * from carti where titlu='".$_POST['titlu']."' and id_auto=".$_POST['id_auto'];
 $resursaCarte = mysql_query($sqlCarte);
 if(mysql_num_rows($resursaCarte)==0)
 {
 print "aceasta carte nu exista in baza de date";
 }
 
 else
 {
 $id_carte = mysql_result($resursaCarte, 0 , id_carte);
 ?>
 esti sigur ca vrei sa stergi aceasta carte ?
 <form action="prelucrare_modificare_stergere.php" method="POST" >
 <input type="hidden" name="id_carte" value="<?=$id_carte?>">
 <input type="submit" name="sterge_carte" value="sterge!">
 </form>
 <?php
 }
 }
 
 ?>
 </body>
 </html>
 