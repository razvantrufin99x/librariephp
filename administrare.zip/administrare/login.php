
	<?php
	if($_POST['nume']=="" || $_POST['parola'] == "")
	{
		print ' trebuei sa completezi amandoua campurile !<br>		<a href="index.php">inapoi</a>';
		exit;
	}
	$debug = 0;
	
	include ("../conectare.php");
	
	
	$parolaEncriptata = md5($_POST['parola']);
	if($debug==1){
	print $parolaEncriptata;
	print '<br>';
	print $_POST['nume'];
	print '<br>';
	print $_POST['parola'];
	print '<br>';
	}
	$sql = "select * from admin where admin_nume ='".$_POST['nume']."' and admin_parola ='".$parolaEncriptata."'";
//SELECT * FROM `admin` WHERE `id_admin` = 1 AND `admin_nume` LIKE 'Trufin' AND `admin_parola` LIKE '1111'
	
	$resursa = mysql_query($sql);
	if($debug==1){
	print mysql_num_rows($resursa);
	}
	
	if(mysql_num_rows($resursa)!=1)
	{
	
	print ' nume sau parola gresite !<br><a href = "index.php"> inapoi </a>';
	exit;
	}
	
	
	
	session_start();
	$_SESSION['nume_admin'] = $_POST['nume'];
	
	$_SESSION['parola_encriptata'] = $parolaEncriptata;
	
	$_SESSION['key_admin'] = session_id();
	
	header("location: admin.php");
	
	?>
	
	<a href= "admin.php">administrare</a>