
	<?php
	include("autorizare.php");
	include("admin_top.php");
	?>
	
	
	
	
	
	<h1> adaugare </h1>
	
	
	
	
	<b> adauga domeniu </a>
	
	
	
	
	<form action="prelucrare_adaugare.php" method="POST" >
	domeniu nou : <input type = "text" name="domeniu_nou">
	<input type ="submit" name="adauga_domeniu" value="adauga">
	</form>
	
	
	
	<b> adauga autor</b>
	
	
	
	
	<form action="prelucrare_adaugare.php" method="POST">
	autor nou: <input type="text" name="autor_nou">
	<input type ="submit" name="adauga_autor" value="adauga">
	</form>
	
	
	
	
	
	
	<b>adauga carte</b>
	
	
	
	
	<form action="prelucrare_adaugare.php" method="POST">
	<table>
	<tr>	<td>	domeniu</td><td>
	
	<select name="id_domeniu">
	<?php
	$sql = "select * from domenii order by nume_domeniu asc";
	$resursa = mysql_query($sql);
	while($row=mysql_fetch_array($resursa))
	{
	print '<option value="'.$row['id_domeniu'].'">'.$row['nume_domeniu'].'</option>';
	}
	
	?>
	
	</select>
	</td>
	</tr>
	
	<tr>
	<td>autor</td>
	<td>
	<select name="id_autor">
	<?php
	$sql = "select * from autori order by nume_autor asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
	print '<option value="'.$row['id_autor'].'">'.$row['nume_autor'].'</option>';
	}
	?>
	
	</select>
	</td>
	</tr>
	
	<tr>
	<td>
	titlu:
	</td>
	<td> <input type="text" name="titlu"> 
	</td>
	</tr>
	
	<tr>
	<td valign="top"> descriere:</td>
	<td> <textarea name="descriere" rows="8"></textarea></td>
	</tr>
	
	<tr>
	<td>pret</td>
	<td><input type="text" name="pret" >
	</td>
	</tr>
	
	<tr>
	<td></td>
	
	<td><input type="submit" name="adaugare_carte" value="adauga"></td>
	
	</tr>
	</table>
	
	</form>
	
	
	</body>
	</html>
	