
	<?php
	include("autorizare.php");
	include("admin_top.php");
	
	if(isset($_POST['adauga_domeniu']))
	{
	if($_POST['domeniu_nou'] == "")
	{
	print ' trebuie sa completezi numele de domeniu!<br>	<a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	$sql = "select * from domenii where nume_domeniu='".$_POST['domeniu_nou']."'";
	$resursa = mysql_query($sql);
	
	if(mysql_num_rows($resursa)!=0)
	{
	print 'domeniu <b>'.$_POST['domeniu_nou'].'</b>exista deja in baza de date !<br><a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	$sql = "insert into domenii (nume_domeniu) values ('".$_POST['domeniu_nou']."')";
	mysql_query($sql);
	print 'Domeniul <b>'.$_POST['domeniu_nou'].'</b> a fost adaugat in baza de date !<br> <a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	
	
	if(isset($_POST['adauga_autor']))
	{
	
	  if($_POST['autor_nou']=="")
	  {
	  print 'trebuie sa completezi numele autorului !<br>  <a href="adaugare.php">inapoi</a>';
	  exit;
	  }
	
	$sql = "select * from autori where nume_autor='".$_POST['autor_nou']."'";
	$resursa = mysql_query($sql);
	if(mysql_num_rows($resursa) !=0)
	{
	print 'autorul <b>'.$_POST['nume_autor'].'</b>	exista deja in baza de date !<br>	<a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	$sql = "insert into autori (nume_autor) values ('".$_POST['autor_nou']."')";
	mysql_query($sql);
	
	print 'autorul <b>'.$_POST['autor_nou'].'</b> a fost adaugat in baza de date !<br>	<a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	
	
	
	
	
	if(isset($_POST['adaugare_carte']))
	{
	if($_POST['titlu']=="" ||	$_POST['descriere']=="" ||	$_POST['pret']=="" )
	{
	print 'titlul, descrierea sau pretul sunt goale!<br>	<a href="adaugare.php">inapoi</a>';
	exit;
	}
	
	
	if(!is_numeric($_POST['pret']))
	{
	print 'campul pret trebuei sa fie de tip numeri ! scrieti <b> 1000</b> in loc de <b>100 lei</b> <br>	<a href ="adaugare.php">inapoi</a>';
	exit;
	}
	
	
	$sql = "select * from carti where id_autor='".$_POST['id_autor']."'	and titlu='".$_POST['titlu']."'";
	$resursa = mysql_query($sql);
	if(mysql_num_rows($resursa) != 0)
	{
	
	print ' aceasta carte exista deja in baza de date !<br>	<a href = "adaugare.php">inapoi</a>';
	exit;
	
	}
	//INSERT INTO `librarie`.`carti` (`id_carte`, `id_autor`, `titlu`, `id_domeniu`, `pret`,  `descriere`) VALUES ('2', '3', 'otello', '1', '21.3',  'nu e o pozie introdusa la deruta');
	$debug = 0;
	if($debug==1){
	print $_POST['id_domeniu'];
	print $_POST['id_autor'];
	print $_POST['titlu'];
	print $_POST['descriere'];
	print $_POST['pret'];
	}
	$sql = "insert into carti (id_domeniu, id_autor, titlu, descriere, pret) values ('".$_POST['id_domeniu']."','".$_POST['id_autor']."','".$_POST['titlu']."','".$_POST['descriere']."','".$_POST['pret']."')";
	//$sql = "INSERT INTO `librarie`.`carti` (`id_carte`, `id_autor`, `titlu`, `id_domeniu`, `pret`,  `descriere`) VALUES ('5', '2', 'otello2', '2', '23.3',  'nu e o pozie introdusa la de333ruta')";
	mysql_query($sql);
	print '<br>cartea a fost adaugat in baza de date!<br>	<a href = "adaugare.php>inapoi</a>';
	exit;
	
	}
	
	?>
	
	</body>
	</html>
	