
	<?php
	include("autorizare.php");
	include("admin_top.php");
	?>
	
	<h1>modificare sau stergere</h1>
	</p>
	
	<b>nota:</b>
	nu veti putea sterge domenii care au carti in ele. inainte 
	de a sterge domeniul, modificati cartile din el astfel incat sa apartina altor domenii. de asemenea nu veti pute asterge un autor daca exista carti in baza de date care au acel autor.</p>
	
	
	
	<b> selecteaza domeniul ce doresti si il modifici sau stergi:</b>
	
	
	<form action = "formulare_modificare_stergere.php" method="POST">
	domeniu :
	<select name="id_domeniu">
	<?php
	$sql = "select * from domenii order by nume_domeniu asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
		print '<option value="'.$row['id_domeniu'].'">'.$row['nume_domeniu'].'</option>';
	
	}
	?>
	
	</select>
	
	<input type="submit" name="modifica_domeniu" value="modifica">
	<input type="submit" name="stergere_domeniu" value="sterge">
	</form>
	
	
	
	
	
	</b> selecteaza autorul ce doresti sa il modifica sau stergi:</b>
	
	
	
	<form action="formulare_modificare_stergere.php" method="POST">
	autor :
	<select name="id_autor">
	
	<?php
	$sql = "select * from autori order by nume_autor asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
	print '<option value="'.$row['id_autor'].'">'.$row['nume_autor'].'</option>';
	
	}
	?>
	
	</select>
	<input type="submit" name="modifica_autor" value="modifica">
	<input type="submit" name="sterge_autor" value="sterge">
	</form>
	
	
	
	<b> selecteaza autorul si scrie titlul cartii ce doresti sa o modifici sau stergi :</b>
	<form action="formulare_modificare_stergere.php" method="POST">
	<table>
	<tr>
	<td>autor:</td>
	<td>
	<select name="id_autor">
	
	<?php
	$sql = "select * from autori order by nume_autor asc";
	$resursa = mysql_query($sql);
	while($row = mysql_fetch_array($resursa))
	{
	print '<option value="'.$row['id_autor'].'">'.$row['nume_autor'].'</option>';
	}
	?>
	
	</select>
	</td>
	</tr>
	<tr>
	<td><titlu:/td>
	<td><input type="text" name="titlu">
	</td>
	</tr>
	</table>
	<input type="submit" name="modifica_carte" value="modifica">
	<input type="submit" name="sterge_carte" value="sterge">
	</form>
	</body>
	</html>
	
	