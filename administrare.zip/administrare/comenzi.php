
<?php
include("autorizare.php");
include("admin_top.php");
?>

<h1>comenzi </h1>
<b> comenzi inca neonorate </b>
<?php
$totalGeneral=0;
$sqlTranzactii = "select id_tranzactie, date_format(data_tranzactie, '%d-%m-%Y') as data_tranzactie, nume_cumparator, adresa_cumparator from tranzactii where comanda_onorata = 0";

$resursaTranzactii = mysql_query($sqlTranzactii);
while($rowTranzactie = mysql_fetch_array($resursaTranzactii))
{
?>
<form action="prelucrare_comenzi.php" method="POST">
data comenzii:
<b><?=$rowTranzactie['data_tranzactie']?>
</b>
<div style="widt:500px; border=1px solid $ffffff; background-color:$f9f1e7; padding:5px">
<b><?=$rowTranzactie['nume_cumparator']?>
</b><br>
<?=$rowTranzactie['adresa_cumparator']?>
<table border="1" cellpadding="4" cellspacing="0">
<tr>
<td align="center" > <b>carte</b></td>
<td align="center" > <b>nr buc</b></td>
<td align="center" > <b>pret</b></td>
<td align="center" > <b>total</b></td>
</tr>
<?php
$sqlCarti = "select titlu, nume_autor, pret , nr_buc from vanzari, carti, autori where carti.id_carte=vanzari.id_carte and carti.id_autor=autori.id_autor and tranzactii.id_tranzactie=".$rowTranzactie['id_tranzactie'];
$resursaCarti = mysql_query($sqlCarti);

while($rowCarte = mysql_fetch_array($resursaCarti))
{
print '<tr><td>'.$rowCarte['titlu'].' de '.$rowCarte['nume_autor'].'</td> ';
print '<td align="right">'.$rowCarte['nr_buc'].'</td>';
print '<td align="right">'.$rowCarte['pret'].' </td>';
$total = $rowCarte['pret'] * $rowCarte['nr_buc'];
print '<td align="right" > '.$total.'</td><tr>';
$totalGeneral = $totalGeneral + $total;
}
?>
<tr>
<td colspan="3" align="right"> total comanda: <td>
<td><?=$totalGeneral?> lei </td>
</tr>
</table>
<input type="hidden" name="id_tranzactie" value="<?=$rowTranzactie['id_tranzactie']?>">
<input type="submit" name="comanda_onorata" value="Comanda onorata">
  <input type="submit" name="anuleaza_comanda" value="anuleaza comanda">
  
  </div>
  </form>
  
  <?php
  }
  ?>
  </body>
  </html>
  
  