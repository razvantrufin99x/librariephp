	
	
	<html>
	<head>
	<meta http_equiv="Content-Type" content="text/html; charset=iso-8859-2">
	<title> libraria mea</title>
	<style type="text/css">
	body, p , td { font-family:Verdana , Arial , sans-sans-serif; font-size 12px;}
	h1 { font-family : Times New Roman, Times , serif; font-size : 18px; font-weight : bold ; color : #336699; font-style : italic :}
	
	titlu { font-family : Verdana , Arial , sans-serif ; font-size : 14px; font-weight : bold ; color ; #0066cc;}
	</style>
	</head>
	<body bgcolor="#ffffff">
	<img src="../logo.gif">
	<table bgcolor="$f9f1e7" cellspacing="0" cellpadding="4" border="1" > 
	<tr>
	<td>
	<a href = "adaugare.php">adauga</a></td>
	<td><a href = "modificare_stergere.php">
	modifica sau sterge </a></td>
	<td><a href ="opinii.php">
	opinii vizitatori</a> </td>
	<td> <a href="comenzi.php">comenzi</a></td>
	</tr>
	</table>
	<br>
	