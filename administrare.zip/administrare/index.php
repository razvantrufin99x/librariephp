
	
	<html>
	<head>
	<neta http_equiv="Content-Type" content ="text/html; charset=iso-8859-2">
	<title>libraria mea</title>
	<style type = "text/css">
	body, p , td { font-family : Verdana, Arial m sans-serif ; font-size : 12px;}
	h1 { font-family : Times New Roman , Times, serif ; font-size : 18px ;
	font-weight: bold ; color : #336699;
	font-style: italic ;}
	
	.titlu { font-family : Verdana , Arial , sans-serif ; font-size : 14px; font-weight : bold ; color : #0066cc;}
	</style>
	</head>
	
	<body bgcolor = "#ffffff">
	<img src = "../logo.gif">
	<h1> Autentificare </h1>
	<form action="login.php" method="POST">
	<table >
	<tr>
	<td align = "right">nume : </td>
	<td><input type="text" name="nume"></td>
	</tr>
	<tr>
	<td align = "right">parola : </td>
	<td><input type="password" name="parola"></td>
	</tr>
	<tr>
	<td> </td>
	<td><input type="submit" value="autentificare"></td>
	</tr>
	</table>
	</form>
	</body>
	</html>
	