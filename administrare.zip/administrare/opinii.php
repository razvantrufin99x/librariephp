
  
  <?php
  include("autorizare.php");
  include("admin_top.php");
  ?>
  
  <h1> modificare sau sterger comentarii utilizatori </h1>
  <b> comentariile utilizatorilor de la ultima moderare </b>
  <?php
  $sql  = "select * from comentarii, admin, carti, autori where comentarii.id_comentariu>admin.ultimul_comentariu_moderat and carti.id_carte = comentarii.id_carte and carti.id_autor=autori.id_autor order by comentarii.id_comentariu asc";
  $resursa = mysql_query($sql);
  while($row = mysql_fetch_array($resursa))
  {
  ?>
  <form action="formulare_moderare_opinii.php" method="POST">
  <div style = " width:500px; border : 1px solid #ffffff; background-color:$f9f1e7; padding:5px">
  <b><?=$row['titlu']?> de 
  <?=$row['nume_autor']?>
  <hr size="1">
  <a href = "mailto:<?=$row['adresa_email']?>">
  <?php=$row['nume_utilizator']?>
  </a><br>
  <?=$row['comentariu']?>
  </div>
  
  
  <input type="hidden" name="id_comentariu" value="<?=$row['id_comentariu']?>">
   <input type="submit" name ="modifica" value="modifica">
    <input type="submit" name ="sterge" value="sterge">
  </form>
  
  <?php
  }
  $nrComentarii = mysql_num_rows($resursa);
  if($nrComentarii>0)
  {
  ?>
  <form action="formulare_moderare_opinii.php" method="POST">
   <input type="hidden" name="ultimul_id" value="<?=$ultimul_id?>">
  <input type="submit" name="seteaza_moderate" value="seteaza aceste comentarii ca fiind moderate">
  </form>
  <?php
  }
  else
  {
  print "<p> nu exista comentarii noi.</p>";
  }
  ?>
  </body>
  </html>
  