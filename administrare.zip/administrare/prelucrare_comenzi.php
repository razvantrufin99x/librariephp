//prelucrare_comenzi.php
  <?
include("autorizare.php");
include("admin_top.php");
print <h1> comenzi </h1>";

?>
 
 if(isset($_POST['coamnda_onorata']))
{
$sql = "update tranzactii set comanda_onorata=".$_POST['id_tranzactie'];
mysql_query($sql);
print "comanda a fost onorata!";
}

if(isset($_POST['anuleaza_comanda']))
{
$sqlTranzactii = "delete from tranzactii where id_tranzactie=".$_POST['id_tranzactie'];
mysql_query($sqlTranzactii);
$sqlCarti = "delete from vanzari where id_tranzactie=".$_POST['id_tranzactie'];
mysql_query($sqlCarti);
print "comanda a fost anulata!";
}
?>
</body>
</html>

