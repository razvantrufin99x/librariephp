//test.php
	<?
	include("f_autorizare.php");

if(!autorizat())
{
print 'access neautorizat!';
	exit;
	}
	
	include("meniu.php");
	include("main.php");
	
	?>
	
	