	
	<?php
	include("autorizare.php");
	include ("admin_top.php");
	//print "aceasta este prima pagina!";
	?>
	
	
	
	