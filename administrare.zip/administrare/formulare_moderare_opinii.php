
  <?php
  include("autorizare.php");
  include("admin_top.php");
  //modificare comm
  if(isset($_POST['modifica']))
  {
  $sql = "select * from comentarii where id_comantariu=".$_POST['id_comentariu'];
  $resursa = mysql_query($sql);
  $row = mysql_fetch_array($resursa);
  ?>
  <h1>modifica</h1>
  <b>modifica acest comentariu </b>
  <form action="prelucrare_moderare_comentarii.php" method = "POST">
  nume : <input type="text" name="nume_utilizator" value="<?=$row['nume_utilizator']?>">
   email : <input type="test" name = "<?$row['adresa_email']?>"><br><br>
   comentariu : <br><textarea name="comentariu" cols="45" rows"8">
   <?=$row['comentariu']?>
   </textarea><br><br>
<input   type="hidden" name="id_comentariu" value="<?=$_POST['id_comentariu']?>">
<input type="submit" name="modifica" value="modifica">
</form>
<?
}
//confirma stergerea
if(isset($_POST['sterge']__
{
?>
<h1>sterge</h1>
esti sigur ca vrei sa stergi acest comentariu ?
<form action="prelucrare_moderare_comentarii.php" method="POST">
<input type="hidden" name="id_comantariu" value="<?=$_POST['id_comentariu']?>">
<input type="submit" name="sterge" value="sterge">
</form>
<?
}

//cofnrim moderare
if(isset($_POST['seteaza_moderate']))
{
?>
<h1> seteaza comentariile ca fiind moderate </h1>
esti sigur ca vrei sa setezi comentariile din apgina precedenta ca fiind moderate ? le-ai verificat pe toate ? 
<form action="prelucrare_moderare_comentarii.php" method="POST">
<input type="hidden" name="ultimul_id" value="<?=$_POST['ultimul_id']?>">
<input type="submit" name="seteaza_moderate" value="Da!">
</form>
<?
}
?>
</body></html>


//prelucrare_moderare_comentarii.php
<?
include("autorizare.php");
include("admin_top.php");
//modifica comentariu
if(isset($_POST['modifica']))
{
if($_POST['nume_utilizator']=="")
{
print "nu ai completat numele utilizatorului!";
}
else if($_POST['adresa_email']=="")
{
print "nu ai completat adresa de email!";
}
else if($_POST['comentariu']=="")
{
print "campul comentarii este gol!";
}
else{
$sql = "update comentarii set nume_utilizator='".$_POST['nume_utilizator']."', 
adresa_email='".$_POST['adresa_email']."',
comentariu='".$_POST['comentariu']."'
where id_comentariu="
.$_POST['id_comantariu'];
mysql_query($sql);
print "comentariul a fost modificat!";
}


//sterge comentariu
if(isset($_POST['sterge']))
{
$sql = "delete from comentarii where id_comantariu=".$_POST['id_comantariu'];
mysql_query($sql);
print "comentariul a fost sters!";
}

//set ultimul comentairu moderat in atbelul admin
if(isset($_POST['seteaza_moderate']))
{
$sql = "update admin set ultimul_comentariu_moderat=".$_POST['ultimul_id'];
mysql_query($sql);
print "valoarea a fost setata!";
}

?>
</body>
</html>
