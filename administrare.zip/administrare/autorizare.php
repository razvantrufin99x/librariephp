
	<?php
	session_start();
	
	$debug=0;
	if($debug==1){
	print $_SESSION['key_admin'];
	
	print "<br>";
	print session_id();
	print "<br>";
	}
	
	if($_SESSION['key_admin'] != session_id())
	{
		print 'access neautorizat !';
		exit;
	}
	
	
	include("../conectare.php");
	
	$sql = "select admin_nume,admin_parola from admin where admin_nume= '".$_SESSION['nume_admin']."' and admin_parola = '".$_SESSION['parola_encriptata']."'";
	$resursa = mysql_query($sql);
	

	if(mysql_num_rows($resursa)!=1)
	{
		if($debug==1){
		print mysql_num_rows($resursa);
		}
		print ' acces neautorizat !';
		exit;
	}
	
	?>
	
	
	<?php
	//include("autorizare.php");
	//print " aceasta este prima pagina!";
	?>
	