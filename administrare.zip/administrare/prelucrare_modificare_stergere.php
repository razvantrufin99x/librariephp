
 <?php

include("autorizare.php");
include("admin_top.php");


//modifica domeniu
if(isset($_POST['modifica']))
{

if($_POST['nume_domeniu']=="")
{
	print "Nu ati introdus numele domeniului";
}
else
{
	$sql = "UPDATE domenii SET nume_domeniu'".$_POST['nume_domeniu']."' where id_domeniu = ".$_POST['id_domeniu'];
	mysql_query($sql);
	print "nume domniu a fost modificat ";
}
}

// stergere domeniu

if(isset($_POST['sterge_domeniu']))
{
$sql = "delete from domenii where id_domeniu =".$_POST['id_domeniu'];
mysql_query($sql);
print "domeniu a fost sters!";
}

//modificare nume autor
if(isset($_POST['modifica_autor']))
{
if($_POST['nume_autor'] == "")
{
print "nu ati introdus numele autorului!";
}
else
{
$sql = " update autori set nume_autor = '".$_POST['nume_autor']."'where id_autor =".$_POST['id_autor'];
mysql_query($sql);
print "numele autorului a fost modificat!";
}
}


//sterge autor
if(isset($_POST['sterge_autor']))
{
$sql = "delete from autori where id_autor=".$_POST['id_autor'];
mysql_query($sql);
print "autorul a fost sters !";
}

// modificare informatii carte
if(isset($_POST['modifica_carte']))
{
if($_POST['titlu']=="")
{
 print " nu ati introdus titlu!";
 }
 else if($_POST['descriere']=="")
 {
 print " nu ati introdus descrierea!";
 }
 else if($_POST['pret']=="")
 {
  print " nu ati introdus pretul !";
  }
  
  else if(!is_numeric($_POST['pret']))
  {
  print "pretul trebuie sa fie numeric ! scrieti <b>1000</b>,  nu <b>1000 lei</b>!";
  }
  
  else
  {
  $sql = "update carti set id_domeniu="  .$_POST['id_domeniu'].  ",  id_autor="  .$_POST['id_autor'].  ",  titlu ='"  .$_POST['titlu'].  "',  descriere  ='"  .$_POST['descriere'].  "',  pret="  .$_POST['pret'].  " where   id_carte ="  .$_POST['id_carte'];
  mysql_query($sql);
  print "informatiile au fost modificate !";
  }
  }
  
  
  
  //sterge carte
  if(isset($_POST['sterge_carte']))
  {
  $sqlCarte = "delete from carti where id_carte =".$_POST['id_carte'];
  mysql_query($sqlCarte);
  $sqlComentarii="delete from comentarii where id_carte=".$_POST['id_carte'];
  mysql_query($sqlComentarii);
  print "cartea a fost stearsa din baza de date !";
  }
  
  ?>
  
  </body>
  </html>
  