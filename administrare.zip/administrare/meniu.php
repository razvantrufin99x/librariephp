//meniu.php
	
	if(!autorizat())
{
print 'access neautorizat!';
	exit;
	}
	
	
	
	alter table carti chane data data timestamp(10) not null;
	
	